package com.example.demo.controller;

import com.example.demo.entity.Spectateur;
import com.example.demo.repository.SpectateurRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequiredArgsConstructor
public class SpectateurController {

    @Autowired
    private SpectateurRepository spectateurRepository;

    @GetMapping ("/coucou")
    public String getCoucou(){
        return "coucou";
    }

    @GetMapping ("/getUsers")
    public List<Spectateur> getUsers(){
        return spectateurRepository.findAll();
    }

    @PostMapping ("/createUsers")
    public Spectateur createUser(@RequestBody Spectateur spectateur){
        return spectateurRepository.save(spectateur);
    }
}
